import { setLineStyle } from '../renderers/draw-line';

import { DrawingUtils } from './ipane-primitive';

export const drawingUtils: DrawingUtils = {
	setLineStyle: setLineStyle,
};
